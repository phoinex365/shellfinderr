
# shellfinder

A Simple Tool to Find Shells and Some Interesting Endpoints in Websites

A shell is malicious PHP file and execute it by accessing it via a web browser. It is a PHP script that allows the attacker to control the server - essentially a backdoor program, similar in functionality to a trojan for personal computers.

## Installation 
Prerequisites:

- Python 3.6

- requests module

1. Put your websites in `websites.txt`

2. Install requests `pip3 install requests`

3. Run the script `$ python3 shellfinder.py`

## Contribution
Please feel free to fork the repository and make pull requests.

Made with love as always.
